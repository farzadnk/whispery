from .whisper_word_level import cli

cli()